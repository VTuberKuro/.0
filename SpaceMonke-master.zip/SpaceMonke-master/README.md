# Gorilla Tag Moon Jump mod

For those interested, you can use this mod as an example for creating other mods, as such here are instructions to build:

 - Clone the repo to a local folder
 - install QPM from the [latest actions here](https://github.com/sc2ad/QuestPackageManager), and add it to your PATH env variable (not neccesary but much easier to work with)
 - install android ndk 21 so you can build for android
 - put a text file named `ndkpath.txt` with the filepath to your ndk `android-ndk-r21` folder

run the build.ps1 script and the mod should be built!

relatively short instructions, but this is to only let those determined enough get this "cheat" mod, for more help you should probably ask in the modding discord
